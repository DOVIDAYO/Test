
import { useState } from "react";
import './App.css';

export default function BrandForm() {
  const [formData, setFormData] = useState({
    name: "",
    capacity: "",
    certification: "",
    price: "",
    description: "",
    image: null,
  });

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: files ? files[0] : value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("제출된 정보:", formData);
    alert("브랜드 정보가 제출되었습니다.");
  };

  return (
    <div className="container">
      <div className="card">
        <h2>화장품 브랜드 정보 등록</h2>
        <form onSubmit={handleSubmit}>
          <label>
            화장품 이름
            <input name="name" value={formData.name} onChange={handleChange} required />
          </label>
          <label>
            용량 (예: 50ml)
            <input name="capacity" value={formData.capacity} onChange={handleChange} required />
          </label>
          <label>
            인증 정보
            <input name="certification" value={formData.certification} onChange={handleChange} />
          </label>
          <label>
            가격 (원화 또는 달러)
            <input name="price" value={formData.price} onChange={handleChange} required />
          </label>
          <label>
            상세 설명
            <textarea name="description" value={formData.description} onChange={handleChange} />
          </label>
          <label>
            제품 이미지
            <input type="file" name="image" accept="image/*" onChange={handleChange} />
          </label>
          <button type="submit">제출하기</button>
        </form>
      </div>
    </div>
  );
}
